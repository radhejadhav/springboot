package com.oauth2server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2serverApplicationTests {

	@Test
	void contextLoads() {
	}

}
